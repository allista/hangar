This addon is needed for smooth upgrade from v1.1.1.1 to v1.2.0.

Do not use it for other versions of the Hangar.